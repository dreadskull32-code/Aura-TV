# AURA TV – Vibrant Glass

A glassmorphism-styled Android TV launcher. This README is the feasibility report, build instructions and known-limitations document for the project — read this before anything else.

## 1. What's actually in this project

A complete, buildable Android Studio / Gradle project (Kotlin, min SDK 21, target SDK 34):

- **Home screen**: app grid (resolution-adaptive column count), compact RAM/storage chips top-left, hamburger icon top-right, no AURA logo on the home screen.
- **Floating dock**: pin/unpin, reorder via the Applications screen, focus magnification, a running-app indicator dot (best-effort, see limitations).
- **Hamburger side panel**: slide-in/out glass panel, the *only* entry point to all settings screens, closes on Back or re-tapping the icon.
- **Settings screens**: Applications (pin management), Display & Picture, TV Settings, Interface Settings (animation speed / reduced motion / dock magnification / focus glow toggles), Wallpaper (picker + live blur/darkness/saturation/gradient preview + crossfade), Privacy, System Manager, About.
- **System monitoring**: real RAM and storage figures from `ActivityManager.MemoryInfo` and `StatFs` — shows an "unavailable" state rather than a fabricated number if a read fails.
- **Wallpaper engine**: custom `WallpaperView` with cover-crop, blur (true backdrop blur via `RenderEffect` on API 31+, a cheap downscale approximation below that), darkness overlay, saturation adjustment, optional gradient overlay, and a crossfade animation.
- **System Manager**: lists every installed app with real enabled/disabled state; deep-links to each app's native "App info" screen (where Android itself offers a Disable button, if the OS permits it for that package); maintains a change-history log and an original-state backup; refuses to offer protected packages (Play services, Play Store, Wi-Fi/Bluetooth, HDMI-CEC, codecs, remote-control input, core Android components, update services) for management at all.

## 2. What is NOT possible on stock, non-rooted Android TV — and what this project does instead

| Requested feature | Reality | What this project does |
|---|---|---|
| Disable/enable other apps' components from inside AURA | Requires `CHANGE_COMPONENT_ENABLED_STATE` (system-signature only), device-owner status, or `adb shell pm disable-user`. A sideloaded app cannot do this on stock Android, root or not. | Lists real enabled/disabled state, deep-links to the OS's own App Info screen where a Disable button may appear, tracks changes made there. |
| Real TV picture controls (contrast, black level, colour temperature, sharpness, gamma, dynamic contrast, noise reduction) | No public Android/AOSP API exposes these; they live in the display controller's firmware behind each OEM's own Settings app, with no published SDK — Sanyo included. | Only touches `Settings.System.SCREEN_BRIGHTNESS` (a real, documented, permission-gated control, with no guarantee it affects backlight on every device) and gives a clearly labelled shortcut button into the TV's native picture menu for everything else. |
| Changing the TV's physical resolution | A launcher cannot do this; it's a display-mode negotiation between the box and the display. | Detects the current resolution/density and adapts layout only; never claims to set resolution. |
| Full "list every running app" visibility | Removed from third-party apps on modern Android for privacy/battery reasons; `getRunningAppProcesses()` now mostly returns your own process's importance bucket. | Uses what that API still returns as a best-effort "running" dot; documented in code as non-authoritative. |
| Wireless ADB debugging on this TV | Only exists on Android 11+. Your earlier messages in this conversation indicated the TV only shows a USB debugging option — i.e. an older Android version. | None of AURA's features require ADB at all. ADB would only ever be needed for edge cases outside this app (e.g. forcing a stubborn disable), and must go through a real computer's USB port in that case. |

## 3. Build instructions (from a phone, no computer needed)

1. Create a GitHub account if you don't have one (github.com, works fine in a phone browser).
2. Create a new **empty** repository (e.g. `aura-tv-launcher`).
3. On the repo page, tap **"Add file → Upload files"**, and upload everything from this project folder, preserving the folder structure (GitHub's web uploader supports dragging/selecting a whole folder on most mobile browsers; if it won't take folders, upload the zip's extracted contents piece by piece, or ask to use a file manager app that can upload folders).
4. Make sure `.github/workflows/build-apk.yml` ends up at that exact path in the repo — this is what tells GitHub to build the APK.
5. Commit directly to the `main` branch.
6. Go to the repo's **Actions** tab. A workflow run called "Build AURA TV APK" should start automatically (or tap **"Run workflow"** if it doesn't).
7. Wait for the run to finish (a few minutes) — a green check means success.
8. Open the finished run, scroll to **Artifacts**, and download `AuraTV-debug-apk` — that's a zip containing `app-debug.apk`.

## 4. Installing on the TV

1. Get `app-debug.apk` onto the TV: easiest is a USB flash drive (copy it from your phone's downloads, plug the drive into the TV), or a cloud folder opened from a TV file-manager app, or any "send to TV" app you already have.
2. On the TV, open a file manager app (install one from the Play Store if none is preinstalled) and tap the APK.
3. If prompted, allow **"Install unknown apps"** for that file manager (Settings → Apps → Special access → Install unknown apps).
4. Install.

## 5. Setting AURA as your Home app, and switching back

- After installing, press the physical Home button on your remote; Android should prompt you to choose a Home app — pick AURA TV and (if asked) "Always".
- To switch back at any time: open AURA's hamburger menu → TV Settings → "Change default Home app" → pick your original Sanyo launcher. (This opens Android's own Home-app chooser — `Settings.ACTION_HOME_SETTINGS` — the real, supported mechanism; AURA cannot do this switch itself.)

## 6. Permissions you may be asked for

- **Usage access** (Settings → Apps → Special access → Usage access → AURA TV): optional, enables a "recently used" signal. AURA works fully without it; without it, that feature is simply empty rather than fabricated.
- **Modify system settings** (triggered automatically if you tap a Display & Picture preset): lets AURA set overall screen brightness only.

## 7. Known limitations (read before reporting a "bug")

- Picture-quality sliders for contrast/colour/sharpness/etc. do not exist in this app because no API exists for them on this hardware — this is disclosed on-screen, not a missing feature.
- The dock's "running" indicator can be wrong or incomplete; Android does not give launchers reliable visibility into other apps' running state anymore.
- Disabling apps happens through Android's own App Info screen, which AURA links to — AURA itself cannot flip that switch.
- Blur on Android versions below 12 (API 31) is an approximation (downscale/upscale), not a true Gaussian blur, to stay lightweight on older TV hardware.

## 8. If the GitHub Actions build fails

- Open the failed run and read the red step — it's almost always either a missing file (re-check the upload preserved the exact folder structure) or an Android SDK license step (the `android-actions/setup-android` action in the workflow auto-accepts licenses, so this should not normally occur).
- Paste the error text back into this conversation and it can be diagnosed from there.
