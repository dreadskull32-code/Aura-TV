package com.auratv.vibrantglass.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.databinding.ActivityWallpaperBinding
import com.auratv.vibrantglass.prefs.PreferencesManager

/**
 * Wallpaper picker + live preview (section 4). Uses the Storage Access
 * Framework (ACTION_OPEN_DOCUMENT) so no broad storage permission is
 * needed on modern Android, and takes a persistable read permission on
 * the chosen Uri so it survives reboots.
 */
class WallpaperActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWallpaperBinding
    private lateinit var prefs: PreferencesManager
    private var pendingUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // Some providers don't support persistable permissions; the
                // preview still works for this session even if it is lost
                // after a reboot, so we don't block on this.
            }
            pendingUri = uri
            binding.previewWallpaperView.setWallpaperUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PreferencesManager(this)

        binding.screenTitle.text = getString(com.auratv.vibrantglass.R.string.menu_wallpaper)
        binding.backButton.setOnClickListener { finish() }

        pendingUri = prefs.getWallpaperUri()
        binding.blurSeekBar.progress = prefs.getBlurPercent()
        binding.darknessSeekBar.progress = prefs.getDarknessPercent()
        binding.saturationSeekBar.progress = prefs.getSaturationPercent()
        binding.gradientOverlayToggle.isChecked = prefs.isGradientOverlayEnabled()

        updatePreviewConfig()
        binding.previewWallpaperView.setWallpaperUri(pendingUri)

        binding.pickImageButton.setOnClickListener { pickImage.launch(arrayOf("image/*")) }

        val seekListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreviewConfig()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        binding.blurSeekBar.setOnSeekBarChangeListener(seekListener)
        binding.darknessSeekBar.setOnSeekBarChangeListener(seekListener)
        binding.saturationSeekBar.setOnSeekBarChangeListener(seekListener)
        binding.gradientOverlayToggle.setOnCheckedChangeListener { _, _ -> updatePreviewConfig() }

        binding.cancelButton.setOnClickListener { finish() }
        binding.applyButton.setOnClickListener {
            prefs.setWallpaperUri(pendingUri)
            prefs.setBlurPercent(binding.blurSeekBar.progress)
            prefs.setDarknessPercent(binding.darknessSeekBar.progress)
            prefs.setSaturationPercent(binding.saturationSeekBar.progress)
            prefs.setGradientOverlayEnabled(binding.gradientOverlayToggle.isChecked)
            finish()
        }
    }

    private fun updatePreviewConfig() {
        binding.previewWallpaperView.setConfig(
            binding.blurSeekBar.progress,
            binding.darknessSeekBar.progress,
            binding.saturationSeekBar.progress,
            binding.gradientOverlayToggle.isChecked,
        )
    }
}
