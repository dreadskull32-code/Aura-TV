package com.auratv.vibrantglass.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.screenTitle.text = getString(R.string.menu_about)
        binding.backButton.setOnClickListener { finish() }
    }
}
