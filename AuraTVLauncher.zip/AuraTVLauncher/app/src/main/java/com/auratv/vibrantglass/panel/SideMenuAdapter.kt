package com.auratv.vibrantglass.panel

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.auratv.vibrantglass.R

enum class SideMenuItem(val titleRes: Int) {
    HOME(R.string.menu_home),
    APPLICATIONS(R.string.menu_applications),
    DISPLAY_PICTURE(R.string.menu_display_picture),
    TV_SETTINGS(R.string.menu_tv_settings),
    INTERFACE_SETTINGS(R.string.menu_interface_settings),
    WALLPAPER(R.string.menu_wallpaper),
    PRIVACY(R.string.menu_privacy),
    SYSTEM_MANAGER(R.string.menu_system_manager),
    ABOUT(R.string.menu_about),
}

/** The slide-out settings panel's menu list — the only entry point into every settings screen, per the brief. */
class SideMenuAdapter(private val onSelect: (SideMenuItem) -> Unit) : RecyclerView.Adapter<SideMenuAdapter.ViewHolder>() {

    private val items = SideMenuItem.values().toList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_side_menu, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.label.setText(item.titleRes)
        holder.label.setOnClickListener { onSelect(item) }
    }

    override fun getItemCount(): Int = items.size

    class ViewHolder(val label: TextView) : RecyclerView.ViewHolder(label)
}
