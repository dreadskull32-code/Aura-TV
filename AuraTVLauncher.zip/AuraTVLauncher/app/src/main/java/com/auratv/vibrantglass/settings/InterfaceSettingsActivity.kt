package com.auratv.vibrantglass.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivityInterfaceSettingsBinding
import com.auratv.vibrantglass.prefs.PreferencesManager

/** Animation-speed and focus-effect toggles (section 5). */
class InterfaceSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInterfaceSettingsBinding
    private lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInterfaceSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PreferencesManager(this)

        binding.header.screenTitle.text = getString(R.string.menu_interface_settings)
        binding.header.backButton.setOnClickListener { finish() }

        if (prefs.isReducedMotion()) {
            binding.animationSpeedGroup.check(binding.speedReduced.id)
        } else {
            val checkedId = when (prefs.getAnimationSpeedMultiplier()) {
                0.5f -> binding.speed05.id
                0.75f -> binding.speed075.id
                1.5f -> binding.speed15.id
                else -> binding.speed1.id
            }
            binding.animationSpeedGroup.check(checkedId)
        }
        binding.dockMagnificationToggle.isChecked = prefs.isDockMagnificationEnabled()
        binding.focusGlowToggle.isChecked = prefs.isFocusGlowEnabled()

        binding.animationSpeedGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                binding.speed05.id -> { prefs.setReducedMotion(false); prefs.setAnimationSpeedMultiplier(0.5f) }
                binding.speed075.id -> { prefs.setReducedMotion(false); prefs.setAnimationSpeedMultiplier(0.75f) }
                binding.speed1.id -> { prefs.setReducedMotion(false); prefs.setAnimationSpeedMultiplier(1.0f) }
                binding.speed15.id -> { prefs.setReducedMotion(false); prefs.setAnimationSpeedMultiplier(1.5f) }
                binding.speedReduced.id -> prefs.setReducedMotion(true)
            }
        }
        binding.dockMagnificationToggle.setOnCheckedChangeListener { _, checked -> prefs.setDockMagnificationEnabled(checked) }
        binding.focusGlowToggle.setOnCheckedChangeListener { _, checked -> prefs.setFocusGlowEnabled(checked) }
    }
}
