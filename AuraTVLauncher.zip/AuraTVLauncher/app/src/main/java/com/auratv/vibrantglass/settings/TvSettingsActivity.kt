package com.auratv.vibrantglass.settings

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivityTvSettingsBinding

/** Shortcuts into system Settings — there is no public TV-settings API for a launcher to host these directly. */
class TvSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTvSettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTvSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.screenTitle.text = getString(R.string.menu_tv_settings)
        binding.backButton.setOnClickListener { finish() }

        binding.openSystemSettingsButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }

        binding.changeHomeAppButton.setOnClickListener {
            // ACTION_HOME_SETTINGS exists from API 24 onward and opens the
            // system's "Home app" chooser, where the Sanyo launcher can be
            // reselected as default at any time — this is the real
            // mechanism; there is no way for AURA to "give back" default
            // status to another app programmatically.
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                } else {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }
}
