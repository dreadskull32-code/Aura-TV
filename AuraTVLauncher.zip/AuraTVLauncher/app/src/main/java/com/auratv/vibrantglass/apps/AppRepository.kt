package com.auratv.vibrantglass.apps

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * Discovers launchable apps the way Android TV itself expects a launcher
 * to: resolving CATEGORY_LEANBACK_LAUNCHER first (apps that declared a TV
 * banner/entry point) and falling back to the normal CATEGORY_LAUNCHER so
 * phone-style apps sideloaded onto the box still show up, per the brief's
 * "handle unavailable apps gracefully" / "support common streaming apps"
 * requirements.
 *
 * Requires android.permission.QUERY_ALL_PACKAGES on API 30+, declared in
 * the manifest, since Android's package-visibility rules would otherwise
 * hide most apps from a third-party launcher.
 */
class AppRepository(private val context: Context) {

    private val pm: PackageManager get() = context.packageManager

    fun loadAllApps(): List<AppInfo> {
        val result = LinkedHashMap<String, AppInfo>()

        val tvIntent = Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER")
        resolve(tvIntent).forEach { result[it.key] = it }

        val standardIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        resolve(standardIntent).forEach { info -> result.putIfAbsent(info.key, info) }

        // Never show ourselves in the grid.
        result.remove(result.keys.firstOrNull { it.startsWith(context.packageName) })

        return result.values.sortedBy { it.label.lowercase() }
    }

    private fun resolve(intent: Intent): List<AppInfo> {
        return try {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            } else null

            @Suppress("DEPRECATION")
            val resolved = if (flags != null) {
                pm.queryIntentActivities(intent, flags)
            } else {
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            }

            resolved.mapNotNull { ri ->
                try {
                    AppInfo(
                        packageName = ri.activityInfo.packageName,
                        componentClassName = ri.activityInfo.name,
                        label = ri.loadLabel(pm)?.toString() ?: ri.activityInfo.packageName,
                        icon = try { ri.loadIcon(pm) } catch (_: Exception) { null },
                    )
                } catch (_: Exception) {
                    // One malformed/unavailable app must not break the whole grid.
                    null
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun launchIntentFor(app: AppInfo): Intent? {
        return pm.getLaunchIntentForPackage(app.packageName)
            ?: Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = android.content.ComponentName(app.packageName, app.componentClassName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
    }

    /**
     * Best-effort "recently used" list. Requires the user to have manually
     * granted Usage Access in system Settings (PACKAGE_USAGE_STATS is a
     * special permission Android will not grant via a normal dialog).
     * Returns an empty list — never a fabricated one — when access is not
     * granted, per the brief's "do not pretend Android provides
     * unrestricted access to every running app's state" requirement.
     */
    fun recentlyUsedPackageNames(limit: Int = 8): List<String> {
        if (!hasUsageAccess()) return emptyList()
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val start = end - 1000L * 60 * 60 * 24 // last 24h
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
            stats.filterNotNull()
                .sortedByDescending { it.lastTimeUsed }
                .map { it.packageName }
                .distinct()
                .filter { it != context.packageName }
                .take(limit)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    context.packageName
                )
            }
            mode == android.app.AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }
}
