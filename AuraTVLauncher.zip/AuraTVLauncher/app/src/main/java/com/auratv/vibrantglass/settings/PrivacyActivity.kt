package com.auratv.vibrantglass.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.auratv.vibrantglass.R
import com.auratv.vibrantglass.databinding.ActivityPrivacyBinding

/** Section 9's privacy shortcuts — all real system screens, no invented controls. */
class PrivacyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.header.screenTitle.text = getString(R.string.menu_privacy)
        binding.header.backButton.setOnClickListener { finish() }

        binding.adSettingsButton.setOnClickListener { safeStart("com.google.android.gms.settings.ACTION_PRIVACY_SETTINGS", Settings.ACTION_SETTINGS) }
        binding.appPermissionsButton.setOnClickListener { safeStart(Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS) }
        binding.usageAccessButton.setOnClickListener { safeStart(Settings.ACTION_USAGE_ACCESS_SETTINGS, Settings.ACTION_SETTINGS) }
    }

    private fun safeStart(primaryAction: String, fallbackAction: String) {
        try {
            startActivity(Intent(primaryAction))
        } catch (_: Exception) {
            try {
                startActivity(Intent(fallbackAction))
            } catch (_: Exception) {
                // Nothing we can safely do if even system Settings won't resolve.
            }
        }
    }
}
